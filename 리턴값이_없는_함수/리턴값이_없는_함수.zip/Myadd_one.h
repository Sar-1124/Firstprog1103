#pragma once

#include <stdio.h>
void add_one(int* p);