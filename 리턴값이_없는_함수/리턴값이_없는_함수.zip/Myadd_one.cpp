void add_one(int* p) {
	(*p) += 1;
}